# Aura ID — Sistema cromático v1.0

Arquivos:
- `index.html`: guia visual responsivo offline com tabelas, swatches, matrizes WCAG e exemplos de card.
- `aura-id-tokens.css`: CSS custom properties (tema claro em `:root`; tema escuro em `.theme-dark`).
- `aura-id-tokens.json`: paleta estruturada com HEX, RGB, OKLCH e matrizes numéricas.

Abrir `index.html` no navegador. Não há dependências externas.

**Sementes preservadas:** #FAF5EE, #4A2036, #B85C38, #C9A227.

**Nota:** a cor terracota 500 no marfim contrasta 4,19:1 e o dourado 2,23:1; não aplicá-las em texto pequeno. Para texto terracota usar secondary-700 #853B25. Embora WCAG não exija 4,5:1 para componentes desabilitados, os tokens `disabled` aqui têm contraste superior em todas as superfícies tabeladas.

OKLCH: conversão sRGB D65 (matrizes OKLab padrão). Contraste: WCAG 2.2, por luminância relativa sRGB. Arredondamentos apenas de exibição.
